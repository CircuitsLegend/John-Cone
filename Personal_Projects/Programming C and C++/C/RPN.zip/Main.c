/******************************************************************************
* Function Title: Main
* 
* Summary: tells you the largest and smallest string based on character value
* 
* Inputs: None
* Outputs: None
* 
* Compile Instructions: gcc Main.c -o main.exe
* *****************************************************************************
* Pseudocode
* 
* Begin
* ask for input and assign it to char array
* check to see if input is an operator or opperand then either push or pop
* end with = char and display answer
* End
******************************************************************************/
#include <stdio.h>//Begin
#include <string.h>
#include <stdlib.h>
#include "main.h"

int main(void)
{
	char sentence[100];
	int a, x, y, z;
	
	printf("Enter an RPN expression: ");//ask for input and assign it to char array
	gets(sentence);
	for (x=0,y=0,z=0;(int)(sentence[x])!=61;x++)
{//check to see if input is an operator or opperand then either push or pop
if (((int)(sentence[x]))!=42&&((int)(sentence[x]))!=43&&((int)(sentence[x]))!=45
&&((int)(sentence[x]))!=47&&((int)(sentence[x]))!=61)
push((int)(sentence[x]));
else 
{
	z=pop(), y=pop();
	if (((int)(sentence[x]))==42)
	{
		a=y*z;
		push(a);
	}
	else if(((int)(sentence[x]))==43)
	{
		a=y+z;
		push(a);
	}
	else if (((int)(sentence[x]))==45)
	{	
		a=y-z;
		push(a);
	}
	else if (((int)(sentence[x]))==47)
	{
		a=y/z;
		push(a);
	}
}
}
if (((int)(sentence[x]))==61)//end with = char and display answer
		printf("Value of expression: %d", pop());

	return 0;//End
}