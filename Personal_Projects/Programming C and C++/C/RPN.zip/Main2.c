
#include <stdio.h>
#include "main.h"
int stack[100];
int top = 0;
/******************************************************************************
* Function Title: make_empty
* 
* Summary: set top to zero
* 
* Inputs: None
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* set top to zero
******************************************************************************/
void make_empty(void)
{//set top to zero
	top=0;
}
/******************************************************************************
* Function Title: is_empty
* 
* Summary: looks to see if top is zero
* 
* Inputs: None
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* looks to see if top is zero
******************************************************************************/
int is_empty(void)
{//looks to see if top is zero
	return top==0;
}
/******************************************************************************
* Function Title: is_full
* 
* Summary: looks to see if top is as big as array
* 
* Inputs: None
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* looks to see if top is as big as array
******************************************************************************/
int is_full(void)
{//looks to see if top is as big as array
	return top==100;
}
/******************************************************************************
* Function Title: push
* 
* Summary: pushes int onto top of stack
* 
* Inputs: None
* Outputs: Int
* *****************************************************************************
* Pseudocode
* 
* pushes int onto top of stack
******************************************************************************/
void push(int i)
{//pushes int onto top of stack
	if (is_full())
		stack_overflow();
	else stack[top++]=i;
}
/******************************************************************************
* Function Title: pop
* 
* Summary: takes number from top of stack
* 
* Inputs: Int
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* takes number from top of stack
******************************************************************************/
int pop(void)
{//takes number from top of stack
	if (is_empty())
		stack_underflow();
	else return stack[--top];
}
/******************************************************************************
* Function Title: stack_overflow
* 
* Summary: if stack is full it tells you you cannot proceed
* 
* Inputs: None
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* if stack is full it tells you you cannot proceed
******************************************************************************/
void stack_overflow(void)
{//if stack is full it tells you you cannot proceed
	printf("Expression is too complex");
}
/******************************************************************************
* Function Title: stack_underflow
* 
* Summary: if stack isn't full enough it tells you you cannot proceed
* 
* Inputs: None
* Outputs: None
* *****************************************************************************
* Pseudocode
* 
* if stack isn't full enough it tells you you cannot proceed
******************************************************************************/
void stack_underflow(void)
{//if stack isn't full enough it tells you you cannot proceed
	printf("Not enough operands in expression");
}