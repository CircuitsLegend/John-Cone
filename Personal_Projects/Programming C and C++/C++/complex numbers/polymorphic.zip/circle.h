#pragma once
/* circle.h ******************************************************************/
#include "point.h"

class Circle : public Point
{
protected:
	float r, a;
public:
	Circle() { x = 0, y = 0, r = 0, a = 0;};//default constructor does nothing
	Circle(float xc, float yc, float rad);
/******************************************************************************
@name print
@brief Circle's print function
@param none
@retval string
******************************************************************************/
	string print()const
	{
		string s;
		s = "Circle with center: (" + to_string(this->x) + " , " + 
			to_string(this->y) +") ; Radius: " + to_string(this->r) + 
			" ; Area: " + to_string(this->a);
		return s;
	}
};