#pragma once
#include <iostream>
#include <string>
using namespace std;

class Shape
{
public:
/******************************************************************************
@name print
@brief pure virtual function to use cout
@param none
@retval string
******************************************************************************/
	virtual string print() const = 0;
/******************************************************************************
@name operator<<
@brief overloads extraction operator
@param ostream by reference and const Shape by reference
@retval ostream by reference
******************************************************************************/
	friend ostream& operator<<(ostream& output, const Shape& s)
	{
		output << s.print() << endl;
		return output;
	}
};