#pragma once
/* point.h *******************************************************************/
#include <iostream>
#include "shape.h"
using namespace std;

class Point : public Shape
{
protected:
	float x, y;
public:
	Point() { x = 0, y = 0; };//default constructor does nothing
	Point(float xc, float yc);
/******************************************************************************
@name print
@brief Point's print function
@param none
@retval string
******************************************************************************/
	string print()const
		{
			string s;
   s = "Point at: ( " + to_string(this->x) + " , " + to_string(this->y) + " )";
			return s;
		}
};