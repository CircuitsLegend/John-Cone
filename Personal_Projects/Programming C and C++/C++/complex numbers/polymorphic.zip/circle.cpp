#include "circle.h"
/******************************************************************************
@name Circle
@brief constructor that assigns protected members
@param x and y coordinates and radius
@retval none
******************************************************************************/
Circle::Circle(float xc, float yc, float rad)
{
	//assign coordinates, radius and area
	x = xc;
	y = yc;
	r = rad;
	a = (float)(3.14159 * r * r);
}