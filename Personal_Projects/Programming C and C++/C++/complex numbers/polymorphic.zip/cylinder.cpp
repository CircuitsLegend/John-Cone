#include "cylinder.h"
/******************************************************************************
@name Cylinder
@brief constructor that assigns protected members
@param x and y coordinates, radius and height
@retval none
******************************************************************************/
Cylinder::Cylinder(float xc, float yc, float rad, float height)
{
	//assign coordinates, radius, area, height and volume
	x = xc;
	y = yc;
	r = rad;
	a = (float)(3.14159 * r * r);
	h = height;
	v = a * h;
}