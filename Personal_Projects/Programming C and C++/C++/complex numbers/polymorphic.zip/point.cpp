#include "point.h"
/******************************************************************************
@name Point
@brief constructor for a point
@param x and y coordinates
@retval none
******************************************************************************/
Point::Point(float xc, float yc)
{
	x = xc; y = yc; //assign coordinates
}