#pragma once
/* cylinder.h ****************************************************************/
#include "circle.h"

class Cylinder : public Circle
{
private:
	float h, v;
public:
	Cylinder(float xc, float yc, float rad, float height);
/******************************************************************************
@name print
@brief Cylinder's print function
@param none
@retval string
******************************************************************************/
	string print()const
	{
		string s;
		s = "Cylinder with center: (" + to_string(this->x) + " , " + 
			to_string(this->y) + ") ; Radius: " + to_string(this->r) + 
			" ; Height: " + to_string(this->h) + " ; Volume: " + 
			to_string(this->v);
		return s;
	}
};